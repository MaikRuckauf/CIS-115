// M3T2
// Maik Ruckauf
// 10/3/2019
// Version 2 of the Recipt Calculator

package m3t2_ruckauf;

/**
 *
 * @author ruckaufm1180
 */

import java.util.Scanner;
import java.text.NumberFormat;
public class M3T2_Ruckauf {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    //Declare variables
    // Declare Real foodCost
    double foodCost;
    // Declare Real taxPct
    double taxPct;
    // Declare Real taxAmount
    double taxAmount;
    // Declare Real tipPct
    double tipPct;
    // Declare Real tipAmount
    double tipAmount;
    // Declare Real totalCost
    double totalCost;
    
    // Ask the user for the cost of their food
    foodCost = getDouble("Please enter the cost of your food");
    
    // Call all of my variables
    taxAmount = calculateTax(foodCost);
    tipAmount = calculateTip(foodCost);
    totalCost = totalCost(foodCost, taxAmount, tipAmount);
    printReceipt(foodCost, taxAmount, tipAmount, totalCost);
    
    }

    public static double getDouble(String prompt)   {
        //get a double from the user
        Scanner keyboard = new java.util.Scanner(System.in);
        System.out.println(prompt);
        double value;
        value = keyboard.nextDouble();
        return value;
    }
    
    public static double calculateTax(double foodCost)  {
        // calculate tax
        double taxPct = 0.06;
        double taxAmount = foodCost * taxPct;
        return taxAmount;
    }
    
    public static double calculateTip(double foodCost)  {
        // calculate tip
        double tipPct = 0.15;
        double tipAmount = foodCost * tipPct;
        return tipAmount;
    }
    
    public static double totalCost(double foodCost, double taxAmount, double tipAmount) {
        // calculate the final cost
        double totalCost = foodCost + taxAmount + tipAmount;
        return totalCost;
    }
    
    public static void printReceipt(double foodCost, double taxAmount, double tipAmount, double totalCost)  {
        // Setup the layout, format, and print receipt
         NumberFormat formatter = NumberFormat.getCurrencyInstance();
        
        System.out.print("Your food cost is: ");
        System.out.println(formatter.format(foodCost));
        
        System.out.print("The tax amount is: ");
        System.out.println(formatter.format(taxAmount));
        
        System.out.print("The tip amount is: ");
        System.out.println(formatter.format(tipAmount));
        
        System.out.print("Your final total is: ");
        System.out.println(formatter.format(totalCost));
         
    }

 
    }


