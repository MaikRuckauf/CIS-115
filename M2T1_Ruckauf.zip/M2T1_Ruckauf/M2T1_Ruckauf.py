##// M2T1
##// Maik Ruckauf
##// 9/17/2019
##
##// ask the user for two integers
##// show the sum and the product
##
##//declare variables
##Declare Integer integer1
##Declare Integer integer2
##Declare Integer sumTotal
##Declare integer productTotal

##// ask user for the first number
##Display "Please enter an integer"
print("Please enter an integer")

##Input integer1
integer1 = int(input())

##// ask user for second number
##Display "Please enter a second integer"
print("Please enter a second integer")

##Input integer2
integer2 = int(input())

##Set sum = integer1 + integer2
sumTotal = integer1 + integer2

##Set product = integer1 * integer2
productTotal = integer1 * integer2

##// display the sum of the numbers
##Display "The sum of the two integers is:"
print("The sum of the two integers is:")
      
##Display sumTotal
print(sumTotal)
      
##// display the product of the numbers
##Display "The product of the two integers is:"
print("The product of the two integers is:")
      
##Display product
print(productTotal)
