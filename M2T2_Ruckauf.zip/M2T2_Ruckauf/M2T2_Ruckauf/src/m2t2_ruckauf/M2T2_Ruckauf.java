
M2T2
Maik Ruckauf
9/19/19
 
package m2t2_ruckauf;
import java.util.Scanner;

/**
 *
 * @author ruckaufm1180
 */
public class M2T2_Ruckauf {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Ask user for name, pay rate, hours worked
        // Tell them gross pay
        
        // Declare variables
        Scanner keyboard = new Scanner(System.in);
        // Declare String name
        String name;
        // Declare Real hourlyRate
        double hourlyRate;
        // Declare Real hoursWorked
        double hoursWorked;
        // Declare Real grossPay
        double grossPay;
        
        // Ask user their name
        // Display "What is your name?"
        System.out.println("What is your name?");
        // Input name
        name = keyboard.nextLine();
        
        // Ask for pay rate
        // Display "How much are you paid per hour?"
        System.out.println("How much are you paid per hour?");
        // Input hourlyRate
        hourlyRate = keyboard.nextDouble();
        
        // Ask for hours worked
        // Display "How many hours did you work this pay period?"
        System.out.println("How many hours did you work this pay period?");
        // Input hoursWorked
        hoursWorked = keyboard.nextDouble();
        
        // Calculate gross pay
        // Set grossPay = hourlyRate * hoursWorked
        grossPay = hourlyRate * hoursWorked;
        

        // Tell the user their gross pay
        // Display "Thanks, ", name
        System.out.println("Thanks,");
        System.out.println(name);
        // Display "Your gross pay is $", grossPay
        System.out.println("Your gross pay is,");
        System.out.println(grossPay);
    }
    
}
