# -*- coding: utf-8 -*-
"""
M2T1
Ruckauf
9/12/19
"""

# convert M2T1 into Python

#// M2LAB
#// Maik Ruckauf
#// 9/12/19
#
#// Greet the user by name,
#// then tell them their age
#// on their next birthday
#
#// Declarations
#Declare String name
#Declare Integer age

#// Ask for their name
#Display "What is your name?"
print("What is your name?")

#Input name
name = input()



#// Ask for their age
#Display "What is your age?"
print("What is your age?")
#Input age
age = int(input())


#// Tell them (by name) how old they will be
#// on their next birthday
#Set age = age + 1
age = age + 1
#Display "Well, ", name, " on your next birthday you will be ", age, "!"
print("Your name is", name)
print("You will be",age,"on your next birthday")