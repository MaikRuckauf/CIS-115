// M3T1
// Maik Ruckauf
// 9/24/2019
package M3T1_Ruckauf;

/**
 *
 * @author ruckaufm1180
 */

import java.util.Scanner;
import java.text.NumberFormat;
public class M3T1_Ruckauf {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    //Declare variables
    Scanner keyboard = new Scanner(System.in);
    NumberFormat formatter = NumberFormat.getCurrencyInstance();
    // Declare Real foodCost
    double foodCost;
    // Declare Real taxPct
    double taxPct;
    // Declare Real taxAmount
    double taxAmount;
    // Declare Real tipPct
    double tipPct;
    // Declare Real tipAmount
    double tipAmount;
    // Declare Real totalCost
    double totalCost;
    
    // Ask the user for the cost of their food
    // Display "Please enter the cost of your food"
    System.out.println("Please enter the cost of your food");
    // Input foodCost
    foodCost = keyboard.nextDouble();
    
    // Calculate 6% tax
    // Set taxPct = 0.06
    taxPct = 0.06;
    // Set taxAmount = foodCost * taxPct
    taxAmount = foodCost * taxPct;

    // Calculate 15% tip
    // Set tipPct = 0.15
    tipPct = 0.15;
    // Set tipAmount = foodCost * tipPct
    tipAmount = foodCost * tipPct;
            
    // Display the food cost
    // Display "Your food cost is $ ", foodCost
    System.out.print("Your food cost is: ");
    System.out.println(formatter.format(foodCost));

    // Display the tax amount
    // Display "The tax amount is 6%"
    System.out.print("The tax amount is: ");
    System.out.println(formatter.format(taxAmount));

    // Display the tip amount
    // Display "The tip amount is 15%"
    System.out.print("The tip amount is: ");
    System.out.println(formatter.format(tipAmount));

    // Display the final total
    // Set totalCost = foodCost + taxAmount + tipAmount
    totalCost = foodCost +taxAmount + tipAmount;
    // Display "Your final total is $ ", totalCost
    System.out.print("Your final total is: ");
    System.out.println(formatter.format(totalCost));
    }
    
}
