// CIS 115 Classwork
// DPS Calculator
package dps;

import java.util.Scanner;
import java.text.NumberFormat;

/**
 *
 * @author ruckaufm1180
 */
public class Dps {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // declare variables
        double damage;
        double delay;
        Scanner keyboard = new Scanner(System.in);
        
        // ask user for damage of weapon
        System.out.println("Weapon damage: ");
        damage = keyboard.nextDouble();
        // ask for delay of weapon
        System.out.println("Weapon delay: ");
         delay = keyboard.nextDouble();
         
        displayDps(damage, delay);
    }
    
    public static void displayDps(double damage, double delay)  {
        // display DPS for a weapon
        // (two decimal places)
        // input: damage, delay
        // output: none
        double dps;
        dps = calculateDps(damage, delay);
        
        // format the number to 2 deciaml places
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);
        String dpsString = nf.format(dps);
        
        System.out.print("Weapon DPS is: ");
        System.out.println(dpsString);
        //or 
        System.out.println("Weapon DPS is: " + dps);
        
    }
    
    public static double calculateDps(double damage, double delay)  {
        // Calculate DPS for a weapon
        // input: damage, delay
        // output: dps
        double dps;
        dps = damage / delay;
        
        return dps;
    }
    
}
